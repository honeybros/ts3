﻿  _____              __          __    _   _          _                               _
 |  __ \      /\     \ \        / /   | \ | |        | |                             | |
 | |__) |    /  \     \ \  /\  / /    |  \| |   ___  | |_  __      __   ___    _ __  | | __  ___
 |  _  /    / /\ \     \ \/  \/ /     | . ` |  / _ \ | __| \ \ /\ / /  / _ \  | '__| | |/ / / __|
 | | \ \   / ____ \     \  /\  /      | |\  | |  __/ | |_   \ V  V /  | (_) | | |    |   <  \__ \
 |_|  \_\ /_/    \_\     \/  \/       |_| \_|  \___|  \__|   \_/\_/    \___/  |_|    |_|\_\ |___/

 _________________________________________________________________________________________________

 Changelog:
 **********************************************
 MultiScript SinusBot Version 4.5
 **********************************************
 - Hinzugefügt: Autostart System
 - Hinzugefügt: Modifizierte Script Verschlüsselung
 - Geändert: Neues Design
 - Geändert: Neues Menü
 - Geändert: Speicherort der Instanzen ist jetzt das Verzeichnis: opt
 - Hinzugefügt: Sprachauswahl ( German & English )


 *******************************
      Systemkompatibilität
 *******************************
    - Debian 8
    - Debian 9
    - Ubuntu


 ********************************************************************************************************************************
          Urheberrecht & Nutzungsbedingungen
 ********************************************************************************************************************************
1. Die Software SinusBot MultiScript ist nicht Open Source.

2. Das Urheberrecht geht an RAW Networks - XendomRecords.

3. Manipulation ist an der Software verboten sowie das entschlüsseln der Software.

4. Wenn das Script manipuliert auf YouTube hochgeladen wurde, kann es wegen Urheberrechtsverletzung entfernt werden.

5. RAW Networks - XendomRecords hat das Recht, die Software jederzeit einzustellen.

6. Die Software ist eine Free Version und darf nicht weiterverkauft werden.

7. Die Nutzungsbedingungen werden beim nutzen des Scripts akzeptiert.

-----------------------------------------------------------------
RAW Networks // YouTube: https://youtube.com/c/RawNetworksYouTube
-----------------------------------------------------------------
